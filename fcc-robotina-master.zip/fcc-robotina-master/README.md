# fcc-robotina
Robotina es un bot utilitario para el canal de FCC Montevideo. Fue creado a partir de ***discord.js*** y el wrapper ***discord.io*** para ser luego hospedado en ***Heroku***.

## Comandos disponibles:

**!help:** --
**!prox:** muestra los detalles del próximo evento **[en desarrollo]**

Contribuyan :)
